import React from "react";

const credentials = () => {
  return (
    <div>
      <h1>Hello</h1>
    </div>
  );
};

export default credentials;
