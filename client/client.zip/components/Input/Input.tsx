import React from "react";

interface InputProps {
  type: string;
  placeholder: string;
  value: string;
  className: string;
}

const Input = ({ type, placeholder, value, className }: InputProps) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      className={className}
    />
  );
};

export default Input;
